#------------------------------------------
# Name:     tests
# Purpose:  Unit tests will go here
#
# Author:   Robin Siebler
# Created:  7/14/13
#------------------------------------------
__author__ = 'Robin Siebler'
__date__ = '7/14/13'

# TODO: add unit tests